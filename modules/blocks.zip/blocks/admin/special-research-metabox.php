<?php
// modules/blocks/admin/special-research-metabox.php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Ajoute la meta box pour les études spéciales
 */
function pokehub_add_special_research_metabox() {
    $screens = apply_filters('pokehub_special_research_post_types', ['post', 'pokehub_event']);
    
    foreach ($screens as $screen) {
        add_meta_box(
            'pokehub_special_research',
            __('Special Research', 'poke-hub'),
            'pokehub_render_special_research_metabox',
            $screen,
            'normal',
            'high'
        );
    }
}
add_action('add_meta_boxes', 'pokehub_add_special_research_metabox');

/**
 * Charge les assets nécessaires pour la meta box
 */
function pokehub_special_research_metabox_assets($hook) {
    global $post;
    
    $allowed_types = apply_filters('pokehub_special_research_post_types', ['post', 'pokehub_event']);
    
    if (!in_array($hook, ['post.php', 'post-new.php']) || !in_array(get_post_type($post), $allowed_types)) {
        return;
    }
    
    // Charger Select2
    wp_enqueue_script('pokehub-admin-select2');
    wp_enqueue_style('pokehub-admin-select2');
    
    // Pas de liste Pokémon en page (recherche via REST). Présélections rendues en PHP (options sélectionnées uniquement).
    wp_localize_script('pokehub-admin-select2', 'pokehubQuestsData', [
        'pokemon' => [],
        'items' => function_exists('pokehub_get_items_for_select') ? pokehub_get_items_for_select() : [],
        'nonce' => wp_create_nonce('pokehub_quests_ajax'),
        'rest_nonce' => wp_create_nonce('wp_rest'),
        'rest_pokemon_url' => rest_url('poke-hub/v1/pokemon-for-select'),
    ]);
}
add_action('admin_enqueue_scripts', 'pokehub_special_research_metabox_assets', 9999);

/**
 * Affiche la meta box
 */
function pokehub_render_special_research_metabox($post) {
    wp_nonce_field('pokehub_save_special_research', 'pokehub_special_research_nonce');
    
    $research = [];
    $research_type = 'special';
    if (function_exists('pokehub_content_get_special_research')) {
        $data = pokehub_content_get_special_research('post', (int) $post->ID);
        $research = isset($data['steps']) ? $data['steps'] : [];
        $research_type = isset($data['research_type']) ? $data['research_type'] : 'special';
        if (defined('WP_DEBUG') && WP_DEBUG && function_exists('error_log')) {
            error_log('[PokeHub SR LOG] render_metabox: post_id=' . $post->ID . ' research_steps_count=' . count($research) . ' research_type=' . $research_type);
        }
    }
    if (empty($research_type)) {
        $research_type = 'special';
    }
    ?>
    <div class="pokehub-special-research-metabox">
        <p>
            <?php _e('Add special research studies for this event. Each study can have multiple steps with quests, and paths can split the scenario.', 'poke-hub'); ?>
        </p>
        
        <div>
            <label>
                <strong><?php _e('Research Type', 'poke-hub'); ?>:</strong>
                <select name="pokehub_special_research_type">
                    <option value="timed" <?php selected($research_type, 'timed'); ?>><?php _e('Timed Research', 'poke-hub'); ?></option>
                    <option value="special" <?php selected($research_type, 'special'); ?>><?php _e('Special Research', 'poke-hub'); ?></option>
                    <option value="masterwork" <?php selected($research_type, 'masterwork'); ?>><?php _e('Masterwork Research', 'poke-hub'); ?></option>
                </select>
            </label>
        </div>
        
        <div id="pokehub-special-research-list">
            <?php if (!empty($research)) : ?>
                <?php foreach ($research as $index => $research_item) : ?>
                    <?php pokehub_render_special_research_editor_item($index, $research_item); ?>
                <?php endforeach; ?>
            <?php else : ?>
                <?php pokehub_render_special_research_editor_item(0, []); ?>
            <?php endif; ?>
        </div>
        
        <button type="button" class="button button-secondary" id="pokehub-add-special-research">
            <?php _e('Add Research', 'poke-hub'); ?>
        </button>
    </div>
    
    <script type="text/template" id="pokehub-special-research-template">
        <?php pokehub_render_special_research_editor_item('{{INDEX}}', []); ?>
    </script>
    
    <style>
        .pokehub-special-research-item-editor {
            border: 1px solid #ddd;
            padding: 15px;
            margin-bottom: 15px;
            background: #fff;
        }
        .pokehub-special-research-item-editor h4 {
            margin-top: 0;
        }
        .pokehub-special-research-step-editor {
            margin: 15px 0;
            padding: 10px;
            background: #f9f9f9;
            border: 1px solid #e0e0e0;
        }
        .pokehub-remove-research,
        .pokehub-remove-step,
        .pokehub-remove-quest,
        .pokehub-remove-reward {
            color: #a00;
        }
        .pokehub-remove-research:hover,
        .pokehub-remove-step:hover,
        .pokehub-remove-quest:hover,
        .pokehub-remove-reward:hover {
            color: #dc3232;
        }
    </style>
    
    <script>
    jQuery(document).ready(function($) {
        // Réappliquer la pré-sélection après init Select2 (Select2 peut avoir vidé/remplacé les options)
        function applyPreselectedPokemon(root) {
            var $root = root ? $(root) : $(document);
            $root.find('select.pokehub-select-pokemon').each(function() {
                var $select = $(this);
                var raw = ($select.attr('data-selected-ids') || '').trim();
                if (!raw) return;
                var ids = raw.split(',').map(function(v) { return String(parseInt(v, 10)); })
                    .filter(function(v) { return v !== 'NaN' && v !== '0'; });
                if (!ids.length) return;
                ids.forEach(function(id) {
                    if ($select.find('option[value="' + id + '"]').length === 0) {
                        $select.append(new Option('#' + id, id, true, true));
                    }
                });
                $select.val(ids).trigger('change');
            });
        }

        // Initialiser Select2 puis réappliquer les présélections
        function initSelect2(ctx) {
            var $sr = $('.pokehub-special-research-metabox');
            var root = (ctx) ? ctx : ($sr.length ? $sr[0] : document);
            if (window.pokehubInitQuestPokemonSelect2) {
                window.pokehubInitQuestPokemonSelect2(root);
            }
            if (window.pokehubInitQuestItemSelect2) {
                window.pokehubInitQuestItemSelect2(root);
            }
            // Réappliquer les présélections après que Select2 ait fini (Select2 en AJAX peut vider le select)
            setTimeout(function() { applyPreselectedPokemon(root); }, 100);
            setTimeout(function() { applyPreselectedPokemon(root); }, 400);
        }

        initSelect2();

        // Ajouter une nouvelle étude
        $('#pokehub-add-special-research').on('click', function() {
            var template = $('#pokehub-special-research-template').html();
            var index = $('#pokehub-special-research-list .pokehub-special-research-item-editor').length;
            var $newResearch = $(template.replace(/\{\{INDEX\}\}/g, index));
            $('#pokehub-special-research-list').append($newResearch);
            initSelect2($newResearch[0]);
        });
        
        // Supprimer une étude
        $(document).on('click', '.pokehub-remove-research', function() {
            if (confirm('<?php echo esc_js(__('Are you sure you want to remove this research?', 'poke-hub')); ?>')) {
                $(this).closest('.pokehub-special-research-item-editor').remove();
            }
        });
        
        // Fonction helper pour générer le HTML d'une étape
        function generateStepHtml(researchIndex, stepIndex, context) {
            var namePrefix = 'pokehub_special_research[' + researchIndex + ']';
            if (context === 'common_initial') {
                namePrefix += '[common_initial_steps][' + stepIndex + ']';
            } else if (context === 'common_final') {
                namePrefix += '[common_final_steps][' + stepIndex + ']';
            } else if (context.indexOf('path_') === 0) {
                var pathIndex = context.replace('path_', '');
                namePrefix += '[paths][' + pathIndex + '][steps][' + stepIndex + ']';
            } else {
                namePrefix += '[steps][' + stepIndex + ']';
            }
            
            return '<div class="pokehub-special-research-step-editor" data-step-index="' + stepIndex + '" data-context="' + context + '">' +
                '<h5><?php echo esc_js(__('Step', 'poke-hub')); ?> #' + (stepIndex + 1) + 
                ' <button type="button" class="button-link pokehub-remove-step"><?php echo esc_js(__('Remove', 'poke-hub')); ?></button></h5>' +
                '<input type="hidden" name="' + namePrefix + '[type]" value="quest" />' +
                '<div class="pokehub-step-quests-editor" style="margin-top: 10px;">' +
                '<strong><?php echo esc_js(__('Quests', 'poke-hub')); ?>:</strong>' +
                '<div class="pokehub-step-quests-list"></div>' +
                '<button type="button" class="button button-small pokehub-add-quest"><?php echo esc_js(__('Add Quest', 'poke-hub')); ?></button>' +
                '</div>' +
                '<div class="pokehub-step-rewards-editor" style="margin-top: 15px;">' +
                '<strong><?php echo esc_js(__('Step Rewards', 'poke-hub')); ?>:</strong>' +
                '<div class="pokehub-step-rewards-list"></div>' +
                '<button type="button" class="button button-small pokehub-add-step-reward"><?php echo esc_js(__('Add Reward', 'poke-hub')); ?></button>' +
                '</div>' +
                '</div>';
        }
        
        // Ajouter une étape commune initiale
        $(document).on('click', '.pokehub-add-common-initial-step', function() {
            var researchItem = $(this).closest('.pokehub-special-research-item-editor');
            var stepIndex = researchItem.find('.pokehub-common-initial-steps-list .pokehub-special-research-step-editor').length;
            var researchIndex = researchItem.data('research-index') || 0;
            var stepHtml = generateStepHtml(researchIndex, stepIndex, 'common_initial');
            $(this).siblings('.pokehub-common-initial-steps-list').append($(stepHtml));
            initSelect2();
        });
        
        // Ajouter une étape commune finale
        $(document).on('click', '.pokehub-add-common-final-step', function() {
            var researchItem = $(this).closest('.pokehub-special-research-item-editor');
            var stepIndex = researchItem.find('.pokehub-common-final-steps-list .pokehub-special-research-step-editor').length;
            var researchIndex = researchItem.data('research-index') || 0;
            var stepHtml = generateStepHtml(researchIndex, stepIndex, 'common_final');
            $(this).siblings('.pokehub-common-final-steps-list').append($(stepHtml));
            initSelect2();
        });
        
        // Ajouter un chemin
        $(document).on('click', '.pokehub-add-path', function() {
            var researchItem = $(this).closest('.pokehub-special-research-item-editor');
            var pathIndex = researchItem.find('.pokehub-special-research-path-editor').length;
            var researchIndex = researchItem.data('research-index') || 0;
            
            var pathHtml = '<div class="pokehub-special-research-path-editor" data-path-index="' + pathIndex + '" style="margin-top: 10px; padding: 10px; background: #fff; border: 2px solid #4a90e2;">' +
                '<h5 style="margin-top: 0;"><?php echo esc_js(__('Path', 'poke-hub')); ?> #' + (pathIndex + 1) + 
                ' <button type="button" class="button-link pokehub-remove-path"><?php echo esc_js(__('Remove', 'poke-hub')); ?></button></h5>' +
                '<label><strong><?php echo esc_js(__('Path Name', 'poke-hub')); ?>:</strong><br>' +
                '<input type="text" name="pokehub_special_research[' + researchIndex + '][paths][' + pathIndex + '][name]" class="widefat" /></label>' +
                '<label style="margin-top: 10px;"><strong><?php echo esc_js(__('Path Image URL', 'poke-hub')); ?>:</strong><br>' +
                '<input type="url" name="pokehub_special_research[' + researchIndex + '][paths][' + pathIndex + '][image_url]" class="widefat" /></label>' +
                '<label style="margin-top: 10px; display: block;"><strong><?php echo esc_js(__('Path Color', 'poke-hub')); ?>:</strong><br>' +
                '<input type="color" name="pokehub_special_research[' + researchIndex + '][paths][' + pathIndex + '][color]" value="#ff6b6b" style="width: 100px; height: 40px; margin-top: 5px; cursor: pointer;" />' +
                '<span style="margin-left: 10px; color: #666; vertical-align: middle;"><?php echo esc_js(__('Color for the path header', 'poke-hub')); ?></span></label>' +
                '<div class="pokehub-path-steps-editor" style="margin-top: 15px;">' +
                '<strong><?php echo esc_js(__('Path Steps', 'poke-hub')); ?>:</strong>' +
                '<div class="pokehub-path-steps-list"></div>' +
                '<button type="button" class="button button-small pokehub-add-path-step"><?php echo esc_js(__('Add Path Step', 'poke-hub')); ?></button>' +
                '</div>' +
                '</div>';
            
            $(this).siblings('.pokehub-paths-list').append($(pathHtml));
            initSelect2();
        });
        
        // Supprimer un chemin
        $(document).on('click', '.pokehub-remove-path', function() {
            $(this).closest('.pokehub-special-research-path-editor').remove();
        });
        
        // Ajouter une étape dans un chemin
        $(document).on('click', '.pokehub-add-path-step', function() {
            var pathEditor = $(this).closest('.pokehub-special-research-path-editor');
            var researchItem = pathEditor.closest('.pokehub-special-research-item-editor');
            var stepIndex = pathEditor.find('.pokehub-path-steps-list .pokehub-special-research-step-editor').length;
            var researchIndex = researchItem.data('research-index') || 0;
            var pathIndex = pathEditor.data('path-index') || 0;
            var stepHtml = generateStepHtml(researchIndex, stepIndex, 'path_' + pathIndex);
            $(this).siblings('.pokehub-path-steps-list').append($(stepHtml));
            initSelect2();
        });
        
        // Supprimer une étape
        $(document).on('click', '.pokehub-remove-step', function() {
            $(this).closest('.pokehub-special-research-step-editor').remove();
        });
        
        // Fonction helper pour générer le nom de base selon le contexte
        function getNameBase(researchIndex, stepIndex, context, questIndex) {
            var nameBase = 'pokehub_special_research[' + researchIndex + ']';
            if (context === 'common_initial') {
                nameBase += '[common_initial_steps][' + stepIndex + ']';
            } else if (context === 'common_final') {
                nameBase += '[common_final_steps][' + stepIndex + ']';
            } else if (context.indexOf('path_') === 0) {
                var pathIndex = context.replace('path_', '');
                nameBase += '[paths][' + pathIndex + '][steps][' + stepIndex + ']';
            } else {
                nameBase += '[steps][' + stepIndex + ']';
            }
            if (questIndex !== undefined && questIndex !== null) {
                nameBase += '[quests][' + questIndex + ']';
            }
            return nameBase;
        }
        
        // Ajouter une quête
        $(document).on('click', '.pokehub-add-quest', function() {
            var stepEditor = $(this).closest('.pokehub-special-research-step-editor');
            var questIndex = stepEditor.find('.pokehub-quest-editor').length;
            var researchIndex = stepEditor.closest('.pokehub-special-research-item-editor').data('research-index') || 0;
            var stepIndex = stepEditor.data('step-index') || 0;
            var context = stepEditor.data('context') || 'common_initial';
            var nameBase = getNameBase(researchIndex, stepIndex, context, questIndex);
            
            var questHtml = '<div class="pokehub-quest-editor" style="margin-top: 10px; padding: 10px; background: #f0f0f0; border: 1px solid #ddd;" data-context="' + context + '" data-quest-index="' + questIndex + '">' +
                '<label><?php echo esc_js(__('Task', 'poke-hub')); ?>: ' +
                '<input type="text" name="' + nameBase + '[quests][' + questIndex + '][task]" class="widefat" /></label>' +
                '<div class="pokehub-quest-rewards-editor" style="margin-top: 10px;">' +
                '<strong><?php echo esc_js(__('Quest Rewards', 'poke-hub')); ?>:</strong>' +
                '<div class="pokehub-quest-rewards-list"></div>' +
                '<button type="button" class="button button-small pokehub-add-quest-reward"><?php echo esc_js(__('Add Reward', 'poke-hub')); ?></button>' +
                '</div>' +
                '<button type="button" class="button-link pokehub-remove-quest"><?php echo esc_js(__('Remove', 'poke-hub')); ?></button>' +
                '</div>';
            
            stepEditor.find('.pokehub-step-quests-list').append($(questHtml));
            initSelect2();
        });
        
        // Supprimer une quête
        $(document).on('click', '.pokehub-remove-quest', function() {
            $(this).closest('.pokehub-quest-editor').remove();
        });
        
        // Ajouter une récompense de quête
        $(document).on('click', '.pokehub-add-quest-reward', function(e) {
            e.preventDefault();
            e.stopPropagation();
            var questEditor = $(this).closest('.pokehub-quest-editor');
            var rewardsList = questEditor.find('.pokehub-quest-rewards-list');
            var rewardIndex = rewardsList.find('.pokehub-quest-reward-editor').length;
            var researchItem = questEditor.closest('.pokehub-special-research-item-editor');
            var stepEditor = questEditor.closest('.pokehub-special-research-step-editor');
            var researchIndex = researchItem.data('research-index') || 0;
            var stepIndex = stepEditor.data('step-index') || 0;
            var context = stepEditor.data('context') || 'common_initial';
            
            // Récupérer l'index de la quête depuis l'attribut data ou calculer
            var questIndex = questEditor.data('quest-index');
            if (questIndex === undefined || questIndex === null) {
                var questsList = questEditor.closest('.pokehub-step-quests-list');
                questIndex = questsList.find('.pokehub-quest-editor').index(questEditor);
                if (questIndex < 0) {
                    questIndex = questEditor.siblings('.pokehub-quest-editor').length;
                }
            }
            
            var nameBase = getNameBase(researchIndex, stepIndex, context, questIndex);
            
            var rewardHtml = '<div class="pokehub-quest-reward-editor" style="margin-top: 10px; padding: 10px; background: #fff; border: 1px solid #ccc;">' +
                '<label><?php echo esc_js(__('Reward Type', 'poke-hub')); ?>: ' +
                '<select name="' + nameBase + '[rewards][' + rewardIndex + '][type]" class="pokehub-reward-type" data-context="' + context + '" data-quest-index="' + questIndex + '">' +
                '<option value="pokemon"><?php echo esc_js(__('Pokémon', 'poke-hub')); ?></option>' +
                '<option value="stardust"><?php echo esc_js(__('Stardust', 'poke-hub')); ?></option>' +
                '<option value="xp"><?php echo esc_js(__('XP', 'poke-hub')); ?></option>' +
                '<option value="item"><?php echo esc_js(__('Item', 'poke-hub')); ?></option>' +
                '</select></label>' +
                '<div class="pokehub-reward-fields" style="margin-top: 10px;"></div>' +
                '<button type="button" class="button-link pokehub-remove-reward"><?php echo esc_js(__('Remove', 'poke-hub')); ?></button>' +
                '</div>';
            
            rewardsList.append($(rewardHtml));
            $('.pokehub-reward-type').last().trigger('change');
            initSelect2();
        });
        
        // Ajouter une récompense d'étape
        $(document).on('click', '.pokehub-add-step-reward', function(e) {
            e.preventDefault();
            e.stopPropagation();
            var stepEditor = $(this).closest('.pokehub-special-research-step-editor');
            var rewardsList = stepEditor.find('.pokehub-step-rewards-list');
            var rewardIndex = rewardsList.find('.pokehub-step-reward-editor').length;
            var researchItem = stepEditor.closest('.pokehub-special-research-item-editor');
            var researchIndex = researchItem.data('research-index') || 0;
            var stepIndex = stepEditor.data('step-index') || 0;
            var context = stepEditor.data('context') || 'common_initial';
            var nameBase = getNameBase(researchIndex, stepIndex, context, null);
            
            var rewardHtml = '<div class="pokehub-step-reward-editor" style="margin-top: 10px; padding: 10px; background: #fff; border: 1px solid #ccc;">' +
                '<label><?php echo esc_js(__('Reward Type', 'poke-hub')); ?>: ' +
                '<select name="' + nameBase + '[rewards][' + rewardIndex + '][type]" class="pokehub-reward-type" data-context="' + context + '">' +
                '<option value="pokemon"><?php echo esc_js(__('Pokémon', 'poke-hub')); ?></option>' +
                '<option value="stardust"><?php echo esc_js(__('Stardust', 'poke-hub')); ?></option>' +
                '<option value="xp"><?php echo esc_js(__('XP', 'poke-hub')); ?></option>' +
                '<option value="item"><?php echo esc_js(__('Item', 'poke-hub')); ?></option>' +
                '</select></label>' +
                '<div class="pokehub-reward-fields" style="margin-top: 10px;"></div>' +
                '<button type="button" class="button-link pokehub-remove-reward"><?php echo esc_js(__('Remove', 'poke-hub')); ?></button>' +
                '</div>';
            
            rewardsList.append($(rewardHtml));
            $('.pokehub-reward-type').last().trigger('change');
            initSelect2();
        });
        
        // Supprimer une récompense
        $(document).on('click', '.pokehub-remove-reward', function() {
            $(this).closest('.pokehub-quest-reward-editor, .pokehub-step-reward-editor').remove();
        });
        
        // Gérer le changement de type de récompense
        $(document).on('change', '.pokehub-reward-type', function() {
            var rewardEditor = $(this).closest('.pokehub-quest-reward-editor, .pokehub-step-reward-editor');
            var type = $(this).val();
            var fieldsContainer = rewardEditor.find('.pokehub-reward-fields');
            var nameAttr = $(this).attr('name');
            
            // Extraire les indices depuis le name
            var matches = nameAttr.match(/\[(\d+)\](?:\[common_initial_steps\]|\[common_final_steps\]|\[paths\]\[(\d+)\]\[steps\]|\[steps\])\[(\d+)\](?:\[quests\]\[(\d+)\])?\[rewards\]\[(\d+)\]/);
            
            if (!matches) return;
            
            var researchIndex = matches[1];
            var pathIndex = matches[2]; // peut être undefined
            var stepIndex = matches[3];
            var questIndex = matches[4]; // peut être undefined
            var rewardIndex = matches[5];
            var context = $(this).data('context') || 'common_initial';
            
            // Si on a un pathIndex, c'est un chemin
            if (pathIndex !== undefined) {
                context = 'path_' + pathIndex;
            } else if (nameAttr.indexOf('[common_initial_steps]') !== -1) {
                context = 'common_initial';
            } else if (nameAttr.indexOf('[common_final_steps]') !== -1) {
                context = 'common_final';
            }
            
            var nameBase = getNameBase(researchIndex, stepIndex, context, questIndex);
            nameBase += '[rewards][' + rewardIndex + ']';
            
            fieldsContainer.empty();
            
            if (type === 'pokemon') {
                fieldsContainer.html(
                    '<label><?php echo esc_js(__('Pokémon', 'poke-hub')); ?>: ' +
                    '<select name="' + nameBase + '[pokemon_ids][]" class="pokehub-select-pokemon" multiple style="width: 100%;"></select></label>'
                );
            } else if (type === 'stardust' || type === 'xp') {
                fieldsContainer.html(
                    '<label><?php echo esc_js(__('Quantity', 'poke-hub')); ?>: ' +
                    '<input type="number" name="' + nameBase + '[quantity]" value="1" min="1" /></label>'
                );
            } else if (type === 'item') {
                fieldsContainer.html(
                    '<label><?php echo esc_js(__('Item', 'poke-hub')); ?>: ' +
                    '<select name="' + nameBase + '[item_id]" class="pokehub-select-item" style="width: 100%;"></select></label>' +
                    '<input type="hidden" name="' + nameBase + '[item_name]" class="pokehub-item-name-field" />' +
                    '<label><?php echo esc_js(__('Quantity', 'poke-hub')); ?>: ' +
                    '<input type="number" name="' + nameBase + '[quantity]" value="1" min="1" /></label>'
                );
            }
            
            initSelect2();
        });
    });
    </script>
    <?php
}

/**
 * Affiche un item d'édition d'étude spéciale
 */
function pokehub_render_special_research_editor_item($index, $research_item) {
    ?>
    <div class="pokehub-special-research-item-editor" data-research-index="<?php echo esc_attr($index); ?>">
        <h4>
            <?php _e('Research', 'poke-hub'); ?> #<?php echo is_numeric($index) ? ($index + 1) : $index; ?>
            <button type="button" class="button-link pokehub-remove-research" style="float:right;">
                <?php _e('Remove', 'poke-hub'); ?>
            </button>
        </h4>
        
        <label>
            <strong><?php _e('Research Name', 'poke-hub'); ?>:</strong><br>
            <input 
                type="text" 
                name="pokehub_special_research[<?php echo esc_attr($index); ?>][name]" 
                value="<?php echo esc_attr($research_item['name'] ?? ''); ?>" 
                class="widefat"
                placeholder="<?php esc_attr_e('e.g., Team Up With Candela', 'poke-hub'); ?>"
            />
        </label>
        
        <div class="pokehub-special-research-structure-editor" style="margin-top: 15px;">
            <strong><?php _e('Research Structure', 'poke-hub'); ?>:</strong>
            
            <!-- Étapes communes initiales -->
            <div class="pokehub-common-initial-steps" style="margin-top: 10px; padding: 10px; background: #f0f8ff; border: 1px solid #b0d4f1;">
                <h5 style="margin-top: 0;">
                    <?php _e('Common Initial Steps', 'poke-hub'); ?>
                    <small style="font-weight: normal; color: #666;"><?php _e('(Steps all users must complete before path selection)', 'poke-hub'); ?></small>
                </h5>
                <div class="pokehub-common-initial-steps-list">
                    <?php if (!empty($research_item['common_initial_steps']) && is_array($research_item['common_initial_steps'])) : ?>
                        <?php foreach ($research_item['common_initial_steps'] as $step_index => $step) : ?>
                            <?php pokehub_render_special_research_step_editor($index, $step_index, $step, 'common_initial'); ?>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                <button type="button" class="button button-small pokehub-add-common-initial-step">
                    <?php _e('Add Common Initial Step', 'poke-hub'); ?>
                </button>
            </div>
            
            <!-- Sélection de chemin -->
            <div class="pokehub-path-selection" style="margin-top: 15px; padding: 10px; background: #fff8dc; border: 1px solid #f0e68c;">
                <h5 style="margin-top: 0;">
                    <?php _e('Path Selection', 'poke-hub'); ?>
                    <small style="font-weight: normal; color: #666;"><?php _e('(Where the research splits into different paths)', 'poke-hub'); ?></small>
                </h5>
                <div class="pokehub-paths-list">
                    <?php if (!empty($research_item['paths']) && is_array($research_item['paths'])) : ?>
                        <?php foreach ($research_item['paths'] as $path_index => $path) : ?>
                            <?php pokehub_render_special_research_path_editor($index, $path_index, $path); ?>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                <button type="button" class="button button-small pokehub-add-path">
                    <?php _e('Add Path', 'poke-hub'); ?>
                </button>
            </div>
            
            <!-- Étapes communes finales -->
            <div class="pokehub-common-final-steps" style="margin-top: 15px; padding: 10px; background: #f0fff0; border: 1px solid #90ee90;">
                <h5 style="margin-top: 0;">
                    <?php _e('Common Final Steps', 'poke-hub'); ?>
                    <small style="font-weight: normal; color: #666;"><?php _e('(Steps all users complete after finishing a path)', 'poke-hub'); ?></small>
                </h5>
                <div class="pokehub-common-final-steps-list">
                    <?php if (!empty($research_item['common_final_steps']) && is_array($research_item['common_final_steps'])) : ?>
                        <?php foreach ($research_item['common_final_steps'] as $step_index => $step) : ?>
                            <?php pokehub_render_special_research_step_editor($index, $step_index, $step, 'common_final'); ?>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                <button type="button" class="button button-small pokehub-add-common-final-step">
                    <?php _e('Add Common Final Step', 'poke-hub'); ?>
                </button>
            </div>
        </div>
    </div>
    <?php
}

/**
 * Affiche un éditeur d'étape
 */
function pokehub_render_special_research_step_editor($research_index, $step_index, $step, $context = 'common_initial') {
    $step_type = $step['type'] ?? 'quest';
    $name_prefix = 'pokehub_special_research[' . $research_index . ']';
    
    // Déterminer le préfixe selon le contexte
    if ($context === 'common_initial') {
        $name_prefix .= '[common_initial_steps][' . $step_index . ']';
    } elseif ($context === 'common_final') {
        $name_prefix .= '[common_final_steps][' . $step_index . ']';
    } else {
        $name_prefix .= '[steps][' . $step_index . ']';
    }
    ?>
    <div class="pokehub-special-research-step-editor" data-step-index="<?php echo esc_attr($step_index); ?>" data-context="<?php echo esc_attr($context); ?>">
        <h5>
            <?php _e('Step', 'poke-hub'); ?> #<?php echo ($step_index + 1); ?>
            <button type="button" class="button-link pokehub-remove-step"><?php _e('Remove', 'poke-hub'); ?></button>
        </h5>
        
        <input type="hidden" name="<?php echo esc_attr($name_prefix); ?>[type]" value="quest" />
        
        <div class="pokehub-step-quests-editor" style="margin-top: 10px;">
            <strong><?php _e('Quests', 'poke-hub'); ?>:</strong>
            <div class="pokehub-step-quests-list">
                <?php if (!empty($step['quests']) && is_array($step['quests'])) : ?>
                    <?php foreach ($step['quests'] as $quest_index => $quest) : ?>
                        <?php pokehub_render_special_research_quest_editor($research_index, $step_index, $quest_index, $quest, $context); ?>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            <button type="button" class="button button-small pokehub-add-quest">
                <?php _e('Add Quest', 'poke-hub'); ?>
            </button>
        </div>
        
        <div class="pokehub-step-rewards-editor" style="margin-top: 15px;">
            <strong><?php _e('Step Rewards', 'poke-hub'); ?>:</strong>
            <div class="pokehub-step-rewards-list">
                <?php if (!empty($step['rewards']) && is_array($step['rewards'])) : ?>
                    <?php foreach ($step['rewards'] as $reward_index => $reward) : ?>
                        <?php pokehub_render_special_research_reward_editor($research_index, $step_index, $reward_index, $reward, 'step', null, $context); ?>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            <button type="button" class="button button-small pokehub-add-step-reward">
                <?php _e('Add Reward', 'poke-hub'); ?>
            </button>
        </div>
    </div>
    <?php
}

/**
 * Affiche un éditeur de chemin avec ses étapes
 */
function pokehub_render_special_research_path_editor($research_index, $path_index, $path) {
    ?>
    <div class="pokehub-special-research-path-editor" data-path-index="<?php echo esc_attr($path_index); ?>" style="margin-top: 10px; padding: 10px; background: #fff; border: 2px solid #4a90e2;">
        <h5 style="margin-top: 0;">
            <?php _e('Path', 'poke-hub'); ?> #<?php echo ($path_index + 1); ?>
            <button type="button" class="button-link pokehub-remove-path"><?php _e('Remove', 'poke-hub'); ?></button>
        </h5>
        
        <label>
            <strong><?php _e('Path Name', 'poke-hub'); ?>:</strong><br>
            <input 
                type="text" 
                name="pokehub_special_research[<?php echo esc_attr($research_index); ?>][paths][<?php echo esc_attr($path_index); ?>][name]" 
                value="<?php echo esc_attr($path['name'] ?? ''); ?>" 
                class="widefat"
                placeholder="<?php esc_attr_e('e.g., Team Up With Candela', 'poke-hub'); ?>"
            />
        </label>
        
        <label style="margin-top: 10px;">
            <strong><?php _e('Path Image URL', 'poke-hub'); ?>:</strong><br>
            <input 
                type="url" 
                name="pokehub_special_research[<?php echo esc_attr($research_index); ?>][paths][<?php echo esc_attr($path_index); ?>][image_url]" 
                value="<?php echo esc_url($path['image_url'] ?? ''); ?>" 
                class="widefat"
            />
        </label>
        
        <label style="margin-top: 10px; display: block;">
            <strong><?php _e('Path Color', 'poke-hub'); ?>:</strong><br>
            <input 
                type="color" 
                name="pokehub_special_research[<?php echo esc_attr($research_index); ?>][paths][<?php echo esc_attr($path_index); ?>][color]" 
                value="<?php echo esc_attr($path['color'] ?? '#ff6b6b'); ?>" 
                style="width: 100px; height: 40px; margin-top: 5px; cursor: pointer;"
            />
            <span style="margin-left: 10px; color: #666; vertical-align: middle;"><?php _e('Color for the path header', 'poke-hub'); ?></span>
        </label>
        
        <div class="pokehub-path-steps-editor" style="margin-top: 15px;">
            <strong><?php _e('Path Steps', 'poke-hub'); ?>:</strong>
            <div class="pokehub-path-steps-list">
                <?php if (!empty($path['steps']) && is_array($path['steps'])) : ?>
                    <?php foreach ($path['steps'] as $step_index => $step) : ?>
                        <?php pokehub_render_special_research_step_editor($research_index, $step_index, $step, 'path_' . $path_index); ?>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            <button type="button" class="button button-small pokehub-add-path-step">
                <?php _e('Add Path Step', 'poke-hub'); ?>
            </button>
        </div>
    </div>
    <?php
}

/**
 * Affiche un éditeur de quête
 */
function pokehub_render_special_research_quest_editor($research_index, $step_index, $quest_index, $quest, $context = 'common_initial') {
    $name_prefix = 'pokehub_special_research[' . $research_index . ']';
    
    // Déterminer le préfixe selon le contexte
    if ($context === 'common_initial') {
        $name_prefix .= '[common_initial_steps][' . $step_index . ']';
    } elseif ($context === 'common_final') {
        $name_prefix .= '[common_final_steps][' . $step_index . ']';
    } elseif (strpos($context, 'path_') === 0) {
        // Extraire l'index du chemin
        $path_index = (int) str_replace('path_', '', $context);
        $name_prefix .= '[paths][' . $path_index . '][steps][' . $step_index . ']';
    } else {
        $name_prefix .= '[steps][' . $step_index . ']';
    }
    ?>
    <div class="pokehub-quest-editor" style="margin-top: 10px; padding: 10px; background: #f0f0f0; border: 1px solid #ddd;" data-context="<?php echo esc_attr($context); ?>" data-quest-index="<?php echo esc_attr($quest_index); ?>">
        <label>
            <?php _e('Task', 'poke-hub'); ?>:
            <input 
                type="text" 
                name="<?php echo esc_attr($name_prefix); ?>[quests][<?php echo esc_attr($quest_index); ?>][task]" 
                value="<?php echo esc_attr($quest['task'] ?? ''); ?>" 
                class="widefat"
            />
        </label>
        
        <div class="pokehub-quest-rewards-editor" style="margin-top: 10px;">
            <strong><?php _e('Quest Rewards', 'poke-hub'); ?>:</strong>
            <div class="pokehub-quest-rewards-list">
                <?php if (!empty($quest['rewards']) && is_array($quest['rewards'])) : ?>
                    <?php foreach ($quest['rewards'] as $reward_index => $reward) : ?>
                        <?php pokehub_render_special_research_reward_editor($research_index, $step_index, $reward_index, $reward, 'quest', $quest_index, $context); ?>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            <button type="button" class="button button-small pokehub-add-quest-reward">
                <?php _e('Add Reward', 'poke-hub'); ?>
            </button>
        </div>
        
        <button type="button" class="button-link pokehub-remove-quest"><?php _e('Remove', 'poke-hub'); ?></button>
    </div>
    <?php
}

/**
 * Affiche un éditeur de récompense
 */
function pokehub_render_special_research_reward_editor($research_index, $step_index, $reward_index, $reward, $context = 'step', $quest_index = null, $step_context = 'common_initial') {
    $reward_type = $reward['type'] ?? 'pokemon';
    $name_base = 'pokehub_special_research[' . $research_index . ']';
    
    // Déterminer le préfixe selon le contexte de l'étape
    if ($step_context === 'common_initial') {
        $name_base .= '[common_initial_steps][' . $step_index . ']';
    } elseif ($step_context === 'common_final') {
        $name_base .= '[common_final_steps][' . $step_index . ']';
    } elseif (strpos($step_context, 'path_') === 0) {
        // Extraire l'index du chemin
        $path_index = (int) str_replace('path_', '', $step_context);
        $name_base .= '[paths][' . $path_index . '][steps][' . $step_index . ']';
    } else {
        $name_base .= '[steps][' . $step_index . ']';
    }
    
    if ($context === 'quest' && $quest_index !== null) {
        $name_base .= '[quests][' . $quest_index . ']';
    }
    $name_base .= '[rewards][' . $reward_index . ']';
    ?>
    <div class="pokehub-<?php echo esc_attr($context); ?>-reward-editor" style="margin-top: 10px; padding: 10px; background: #fff; border: 1px solid #ccc;">
        <label>
            <?php _e('Reward Type', 'poke-hub'); ?>:
            <select name="<?php echo esc_attr($name_base); ?>[type]" class="pokehub-reward-type">
                <option value="pokemon" <?php selected($reward_type, 'pokemon'); ?>><?php _e('Pokémon', 'poke-hub'); ?></option>
                <option value="stardust" <?php selected($reward_type, 'stardust'); ?>><?php _e('Stardust', 'poke-hub'); ?></option>
                <option value="xp" <?php selected($reward_type, 'xp'); ?>><?php _e('XP', 'poke-hub'); ?></option>
                <option value="item" <?php selected($reward_type, 'item'); ?>><?php _e('Item', 'poke-hub'); ?></option>
            </select>
        </label>
        
        <div class="pokehub-reward-fields" style="margin-top: 10px;">
            <?php
            if ($reward_type === 'pokemon') {
                // Normalisation en int : WordPress/JSON renvoient souvent des strings ("25") alors que $opt_id est int → in_array(..., true) ne matche jamais sans ça
                $saved_pokemons = $reward['pokemon_ids'] ?? [];
                if (is_string($saved_pokemons)) {
                    $selected_pokemon_ids = array_values(array_filter(array_map('intval', explode(',', $saved_pokemons)), function ($id) {
                        return $id > 0;
                    }));
                } else {
                    $selected_pokemon_ids = array_values(array_unique(array_map('intval', (array) $saved_pokemons)));
                    $selected_pokemon_ids = array_values(array_filter($selected_pokemon_ids, function ($id) {
                        return $id > 0;
                    }));
                }
                // Debug: tracer les données reçues (à retirer après diagnostic)
                if (defined('WP_DEBUG') && WP_DEBUG && function_exists('error_log')) {
                    error_log('[PokeHub Special Research] reward_editor pokemon: reward=' . wp_json_encode($reward) . ' selected_pokemon_ids=' . wp_json_encode($selected_pokemon_ids));
                }
                ?>
                <label>
                    <?php _e('Pokémon', 'poke-hub'); ?>:
                    <select
                        name="<?php echo esc_attr($name_base); ?>[pokemon_ids][]"
                        class="pokehub-select-pokemon"
                        multiple
                        style="width: 100%; min-width: 250px;"
                        data-selected-ids="<?php echo esc_attr(implode(',', $selected_pokemon_ids)); ?>"
                    >
                        <?php
                        // Options des Pokémon déjà sélectionnés (libellés pour la présélection ; recherche complète via REST en JS).
                        if (!empty($selected_pokemon_ids)) {
                            $pokemon_list = [];
                            if (function_exists('pokehub_get_pokemon_for_select_filtered')) {
                                $pokemon_list = pokehub_get_pokemon_for_select_filtered($selected_pokemon_ids, '');
                            }
                            $by_id = [];
                            foreach ($pokemon_list as $pokemon_option) {
                                $by_id[(int) $pokemon_option['id']] = $pokemon_option['text'];
                            }
                            foreach ($selected_pokemon_ids as $id) {
                                $label = isset($by_id[$id]) ? $by_id[$id] : '#' . $id;
                                echo '<option value="' . esc_attr($id) . '" selected="selected">' . esc_html($label) . '</option>';
                            }
                        }
                        ?>
                    </select>
                </label>
                <?php
            } elseif ($reward_type === 'stardust' || $reward_type === 'xp') {
                ?>
                <label>
                    <?php _e('Quantity', 'poke-hub'); ?>: 
                    <input 
                        type="number" 
                        name="<?php echo esc_attr($name_base); ?>[quantity]" 
                        value="<?php echo esc_attr($reward['quantity'] ?? 1); ?>" 
                        min="1" 
                    />
                </label>
                <?php
            } elseif ($reward_type === 'item') {
                $selected_item_id = isset($reward['item_id']) ? (int) $reward['item_id'] : 0;
                ?>
                <label>
                    <?php _e('Item', 'poke-hub'); ?>: 
                    <select 
                        name="<?php echo esc_attr($name_base); ?>[item_id]" 
                        class="pokehub-select-item" 
                        style="width: 100%; min-width: 250px;"
                    >
                        <option value=""><?php _e('Select an item', 'poke-hub'); ?></option>
                        <?php
                        if ($selected_item_id > 0 && function_exists('pokehub_get_item_data_by_id')) {
                            $item_data = pokehub_get_item_data_by_id($selected_item_id);
                            if ($item_data) {
                                $name_fr = $item_data['name_fr'] ?? '';
                                $name_en = $item_data['name_en'] ?? '';
                                $text = $name_fr;
                                if ($name_en && $name_fr !== $name_en) {
                                    $text .= ' (' . $name_en . ')';
                                } elseif (!$name_fr && $name_en) {
                                    $text = $name_en;
                                }
                                echo '<option value="' . esc_attr($selected_item_id) . '" selected>' . esc_html($text) . '</option>';
                            }
                        }
                        ?>
                    </select>
                </label>
                <input type="hidden" name="<?php echo esc_attr($name_base); ?>[item_name]" class="pokehub-item-name-field" value="<?php echo esc_attr($reward['item_name'] ?? ''); ?>" />
                <label>
                    <?php _e('Quantity', 'poke-hub'); ?>: 
                    <input 
                        type="number" 
                        name="<?php echo esc_attr($name_base); ?>[quantity]" 
                        value="<?php echo esc_attr($reward['quantity'] ?? 1); ?>" 
                        min="1" 
                    />
                </label>
                <?php
            }
            ?>
        </div>
        
        <button type="button" class="button-link pokehub-remove-reward"><?php _e('Remove', 'poke-hub'); ?></button>
    </div>
    <?php
}

/**
 * Sauvegarde des études spéciales
 */
function pokehub_save_special_research_metabox($post_id) {
    // Vérifications de sécurité
    if (!isset($_POST['pokehub_special_research_nonce']) || 
        !wp_verify_nonce($_POST['pokehub_special_research_nonce'], 'pokehub_save_special_research')) {
        return;
    }

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    $research_type = isset($_POST['pokehub_special_research_type']) ? sanitize_text_field($_POST['pokehub_special_research_type']) : 'special';

    if (isset($_POST['pokehub_special_research']) && is_array($_POST['pokehub_special_research'])) {
        pokehub_save_special_research($post_id, $_POST['pokehub_special_research'], $research_type);
    } elseif (function_exists('pokehub_content_save_special_research')) {
        pokehub_content_save_special_research('post', $post_id, ['research_type' => $research_type, 'steps' => []]);
    }
}
add_action('save_post', 'pokehub_save_special_research_metabox');

