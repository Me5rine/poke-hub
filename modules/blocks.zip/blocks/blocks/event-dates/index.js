/**
 * Enregistrement côté client du bloc "Dates d'événement"
 * 
 * Même si le bloc est entièrement rendu côté serveur (render.php),
 * WordPress a besoin de ce fichier JavaScript pour afficher le bloc dans l'éditeur.
 */
(function() {
    'use strict';

    // Vérifier que wp.blocks est disponible
    if (typeof wp === 'undefined' || !wp.blocks) {
        return;
    }

    var registerBlockType = wp.blocks.registerBlockType;
    var __ = wp.i18n.__;
    var el = wp.element.createElement;
    var useBlockProps = wp.blockEditor && wp.blockEditor.useBlockProps;

    // Enregistrer le bloc (le rendu est géré par render.php)
    registerBlockType('pokehub/event-dates', {
        edit: function() {
            var props = useBlockProps ? useBlockProps({ className: 'pokehub-block-placeholder' }) : { className: 'pokehub-block-placeholder' };

            return el(
                'div',
                props,
                el('p', {}, __('Event Dates', 'poke-hub')),
                el('small', {}, __('This block automatically displays the event dates.', 'poke-hub'))
            );
        },
        save: function() {
            // Bloc dynamique, pas de save
            return null;
        }
    });
})();








